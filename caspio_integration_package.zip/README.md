# Caspio Integration for Smarty Pants Trivia Co.

## Overview

This package includes all necessary components to integrate the Smarty Pants Trivia Co. application with Caspio database services. The integration allows for event data to be shared directly with Caspio through a secure API connection, with a fallback mechanism to manual form submission.

## Components

### Server-Side Components

- **caspio.ts**: Server-side routes and authentication for Caspio API
  - Handles authentication with Caspio API
  - Processes data sharing requests
  - Provides configuration status endpoints
  - Includes a test connection endpoint

### Client-Side Components

- **caspioConfig.ts**: Configuration settings for the Caspio integration
  - Defines data structure for Caspio communication
  - Sets up fallback form URLs
  - Provides configuration defaults

- **caspioService.ts**: Service for interacting with Caspio
  - Handles API communication
  - Implements fallback mechanisms
  - Manages error handling and user notifications

- **CaspioStatusIndicator.tsx**: UI component showing connection status
  - Displays a visual indicator of Caspio connection status
  - Shows detailed status information on hover

- **caspio-settings.tsx**: Admin page for managing Caspio settings
  - Provides a UI for viewing connection status
  - Allows testing the Caspio connection
  - Displays missing credential information

- **ShareableEventCard.tsx**: Event card with Caspio sharing capability
  - Example implementation of "Share to Caspio" functionality
  - Shows loading state during sharing
  - Handles success/error states with user feedback

## Setup Instructions

1. Set up environment variables:
   - `CASPIO_ACCOUNT_ID`: Your Caspio account identifier
   - `CASPIO_USERNAME`: Your Caspio username
   - `CASPIO_PASSWORD`: Your Caspio password
   - `CASPIO_APP_KEY`: (Optional) Your Caspio application key if available
   - `CASPIO_TABLE_ID`: (Optional) Table ID for data submission (defaults to 'Events')

2. Register the Caspio routes in your Express app:
   ```typescript
   import { registerCaspioRoutes } from './routes/caspio';
   
   // In your app setup
   registerCaspioRoutes(app);
   ```

3. Import and use the client components as needed:
   - Add the CaspioStatusIndicator to your Navbar
   - Include the caspio-settings page in your admin portal
   - Use the ShareableEventCard component or implement the sharing functionality in your own components

## Authentication Flows

The integration supports both authentication flows:
1. Standard flow with username/password and APP_KEY
2. Simplified flow with just username/password (when APP_KEY is unavailable)

## Fallback Mechanism

If direct API communication fails, the system will automatically fall back to opening a Caspio form in a new browser window, pre-filled with the event data. This ensures data can still be shared even if API access is temporarily unavailable.

## Security Considerations

- All authentication occurs server-side; credentials are never exposed to the client
- API tokens are cached with appropriate expiry times
- Sensitive data is properly sanitized before transmission