import { useState, useEffect } from 'react';
import axios from 'axios';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';

/**
 * Component to display the status of Caspio integration
 * Shows a colored indicator based on connection status
 */
export default function CaspioStatusIndicator() {
  const [status, setStatus] = useState<'loading' | 'connected' | 'disconnected'>('loading');
  const [statusMessage, setStatusMessage] = useState<string>('Checking Caspio connection...');

  useEffect(() => {
    const checkStatus = async () => {
      try {
        const response = await axios.get('/api/caspio/config');
        
        if (response.data.configured) {
          setStatus('connected');
          setStatusMessage('Connected to Caspio API');
        } else {
          setStatus('disconnected');
          
          if (response.data.missingCredentials) {
            setStatusMessage(`Missing Caspio credentials: ${response.data.missingCredentials.join(', ')}`);
          } else {
            setStatusMessage(response.data.message || 'Caspio integration is not configured');
          }
        }
      } catch (error) {
        console.error('Error checking Caspio status:', error);
        setStatus('disconnected');
        setStatusMessage('Error connecting to Caspio API');
      }
    };

    checkStatus();
  }, []);

  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>
          <div className="flex items-center">
            <div 
              className={`h-2.5 w-2.5 rounded-full mr-2 ${
                status === 'loading' 
                  ? 'bg-gray-400 animate-pulse' 
                  : status === 'connected' 
                    ? 'bg-green-500' 
                    : 'bg-amber-500'
              }`}
            />
            <span className="text-xs text-gray-500">Caspio</span>
          </div>
        </TooltipTrigger>
        <TooltipContent>
          <p>{statusMessage}</p>
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
}