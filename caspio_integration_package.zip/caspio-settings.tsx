import { useState, useEffect } from 'react';
import axios from 'axios';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/hooks/useAuth';
import PortalLayout from '@/components/portal/PortalLayout';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';

/**
 * Admin page for managing Caspio integration settings
 */
export default function CaspioSettingsPage() {
  const [status, setStatus] = useState<'loading' | 'connected' | 'disconnected'>('loading');
  const [missingCredentials, setMissingCredentials] = useState<string[]>([]);
  const [lastSync, setLastSync] = useState<string | null>(null);
  const [testResult, setTestResult] = useState<{success: boolean, message: string} | null>(null);
  const { toast } = useToast();
  const { user, isVenue, isAdmin } = useAuth();

  // Redirect non-admin users
  useEffect(() => {
    if (user && !isAdmin) {
      window.location.href = '/portal';
    }
  }, [user, isAdmin]);

  // Check Caspio connection status
  useEffect(() => {
    const checkStatus = async () => {
      try {
        const response = await axios.get('/api/caspio/config');
        
        if (response.data.configured) {
          setStatus('connected');
        } else {
          setStatus('disconnected');
          
          if (response.data.missingCredentials) {
            setMissingCredentials(response.data.missingCredentials);
          }
        }
      } catch (error) {
        console.error('Error checking Caspio status:', error);
        setStatus('disconnected');
      }
    };

    checkStatus();

    // Simulated last sync time (this would come from your database)
    const mockLastSync = new Date();
    mockLastSync.setHours(mockLastSync.getHours() - 2);
    setLastSync(mockLastSync.toISOString());
  }, []);

  // Handle test connection
  const handleTestConnection = async () => {
    try {
      setTestResult(null);
      
      toast({
        title: "Testing Connection",
        description: "Attempting to connect to Caspio...",
      });
      
      const response = await axios.post('/api/caspio/test-connection');
      
      if (response.data.success) {
        setTestResult({
          success: true,
          message: "Successfully connected to Caspio API!"
        });
        
        toast({
          title: "Connection Successful",
          description: "Successfully connected to Caspio API!",
        });
      } else {
        setTestResult({
          success: false,
          message: response.data.message || "Failed to connect to Caspio"
        });
        
        toast({
          title: "Connection Failed",
          description: response.data.message || "Failed to connect to Caspio",
          variant: "destructive"
        });
      }
    } catch (error: any) {
      setTestResult({
        success: false,
        message: error.response?.data?.message || error.message || "Unknown error occurred"
      });
      
      toast({
        title: "Connection Failed",
        description: "An error occurred while testing the connection",
        variant: "destructive"
      });
    }
  };

  // If user is not admin, show access denied
  if (user && !isAdmin) {
    return (
      <PortalLayout>
        <div className="container mx-auto py-10">
          <h1 className="text-2xl font-bold mb-4">Access Denied</h1>
          <p>You do not have permission to access this page.</p>
        </div>
      </PortalLayout>
    );
  }

  return (
    <PortalLayout>
      <div className="container mx-auto py-10 max-w-4xl">
        <h1 className="text-3xl font-bold mb-6">Caspio Integration Settings</h1>
        
        <div className="grid gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Connection Status</CardTitle>
              <CardDescription>
                Current status of the Caspio API integration
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center">
                {status === 'loading' ? (
                  <div className="flex items-center">
                    <div className="animate-spin w-5 h-5 border-2 border-blue-500 border-t-transparent rounded-full mr-2"></div>
                    <p>Checking connection status...</p>
                  </div>
                ) : status === 'connected' ? (
                  <div className="flex items-center text-green-600">
                    <svg 
                      xmlns="http://www.w3.org/2000/svg" 
                      className="h-5 w-5 mr-2" 
                      viewBox="0 0 20 20" 
                      fill="currentColor"
                    >
                      <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                    </svg>
                    <span className="font-medium">Connected to Caspio API</span>
                  </div>
                ) : (
                  <div className="flex items-center text-amber-600">
                    <svg 
                      xmlns="http://www.w3.org/2000/svg" 
                      className="h-5 w-5 mr-2" 
                      viewBox="0 0 20 20" 
                      fill="currentColor"
                    >
                      <path fillRule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
                    </svg>
                    <span className="font-medium">Caspio API not connected</span>
                  </div>
                )}
              </div>
              
              {status === 'disconnected' && missingCredentials.length > 0 && (
                <div className="mt-4 p-4 bg-amber-50 border border-amber-200 rounded-md">
                  <h4 className="text-sm font-medium text-amber-800 mb-2">Missing Credentials</h4>
                  <ul className="list-disc pl-5 text-sm text-amber-700 space-y-1">
                    {missingCredentials.map(cred => (
                      <li key={cred}>{cred}</li>
                    ))}
                  </ul>
                  <p className="mt-3 text-sm text-amber-700">
                    Please contact the system administrator to set these environment variables.
                  </p>
                </div>
              )}
              
              {lastSync && (
                <div className="mt-4 text-sm text-gray-600">
                  <span className="font-medium">Last successful sync: </span>
                  {new Date(lastSync).toLocaleString()}
                </div>
              )}
              
              {testResult && (
                <div className={`mt-4 p-4 border rounded-md ${testResult.success ? 'bg-green-50 border-green-200' : 'bg-red-50 border-red-200'}`}>
                  <div className="flex items-center">
                    {testResult.success ? (
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-green-500 mr-2" viewBox="0 0 20 20" fill="currentColor">
                        <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                      </svg>
                    ) : (
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-red-500 mr-2" viewBox="0 0 20 20" fill="currentColor">
                        <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
                      </svg>
                    )}
                    <span className={`font-medium ${testResult.success ? 'text-green-700' : 'text-red-700'}`}>
                      {testResult.message}
                    </span>
                  </div>
                </div>
              )}
            </CardContent>
            <CardFooter>
              <Button 
                onClick={handleTestConnection}
                disabled={status === 'loading' || status === 'disconnected'}
              >
                Test Connection
              </Button>
            </CardFooter>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Integration Information</CardTitle>
              <CardDescription>
                Details about how the Caspio integration works
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <h3 className="text-lg font-medium">Shared Data</h3>
                  <p className="text-gray-600">
                    The following data is shared with Caspio when users share events:
                  </p>
                  <ul className="list-disc pl-5 mt-2 space-y-1 text-gray-600">
                    <li>Event ID</li>
                    <li>Event Title</li>
                    <li>Event Description</li>
                    <li>Event Date</li>
                    <li>Venue Name</li>
                    <li>Image URL (if available)</li>
                    <li>Timestamp of sharing</li>
                  </ul>
                </div>
                
                <div>
                  <h3 className="text-lg font-medium">Fallback Method</h3>
                  <p className="text-gray-600">
                    If the API connection is not available, the system will fall back to opening a 
                    Caspio form in a new window, pre-filled with event data.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </PortalLayout>
  );
}