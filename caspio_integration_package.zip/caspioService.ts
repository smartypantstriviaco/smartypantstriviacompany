import axios from 'axios';
import { toast } from '@/hooks/use-toast';
import { getCaspioFormUrl, prepareCaspioData, defaultCaspioConfig } from './caspioConfig';

interface CaspioShareResponse {
  success: boolean;
  message: string;
  data?: any;
}

/**
 * Service to handle interactions with Caspio
 */
export class CaspioService {
  /**
   * Share data with Caspio using the API
   * 
   * @param data The data to be shared with Caspio
   * @returns Response object with success status and message
   */
  static async shareWithCaspio(data: any): Promise<CaspioShareResponse> {
    try {
      // Format data according to Caspio structure
      const formattedData = prepareCaspioData(data);
      
      // Attempt to share via API
      const response = await axios.post('/api/caspio/share', {
        data: formattedData
      });
      
      return {
        success: true,
        message: 'Successfully shared data with Caspio',
        data: response.data
      };
    } catch (error: any) {
      console.error('Error sharing with Caspio:', error);
      
      // Return error response
      return {
        success: false,
        message: error.response?.data?.message || 'Failed to share data with Caspio',
      };
    }
  }
  
  /**
   * Fall back to opening a Caspio form in a new window
   * This is used if the API sharing fails
   * 
   * @param data The data to pre-fill in the Caspio form 
   * @param tableId The Caspio table ID
   */
  static openCaspioForm(data: any, tableId: string = defaultCaspioConfig.tableId): void {
    try {
      // Format data according to Caspio structure
      const formattedData = prepareCaspioData(data);
      
      // Get the Caspio form URL
      const baseUrl = getCaspioFormUrl(tableId);
      
      // Construct URL with query parameters for pre-filling form
      const queryParams = new URLSearchParams();
      
      // Add each data field as a query parameter
      Object.entries(formattedData).forEach(([key, value]) => {
        if (value !== undefined && value !== null) {
          queryParams.append(key, String(value));
        }
      });
      
      // Construct the final URL
      const fullUrl = `${baseUrl}?${queryParams.toString()}`;
      
      // Open the Caspio form in a new window
      window.open(fullUrl, '_blank', 'noopener,noreferrer');
      
      // Notify user
      toast({
        title: 'Using Fallback Method',
        description: 'A Caspio form has been opened in a new window',
      });
    } catch (error) {
      console.error('Error opening Caspio form:', error);
      
      // Notify user of failure
      toast({
        title: 'Error',
        description: 'Failed to open Caspio form',
        variant: 'destructive',
      });
    }
  }
  
  /**
   * Share data with Caspio with fallback
   * Tries the API first, then falls back to opening a form if configured
   * 
   * @param data The data to share with Caspio
   * @param config Optional configuration overrides
   * @returns Success status of the operation
   */
  static async shareWithFallback(
    data: any, 
    config = defaultCaspioConfig
  ): Promise<boolean> {
    try {
      // First try API sharing
      const response = await this.shareWithCaspio(data);
      
      if (response.success) {
        // API sharing succeeded
        toast({
          title: 'Shared Successfully',
          description: 'Data has been shared with Caspio',
        });
        return true;
      } else if (config.useFallbackForm) {
        // API sharing failed, use fallback form
        this.openCaspioForm(data, config.tableId);
        return true;
      } else {
        // API sharing failed and no fallback configured
        toast({
          title: 'Sharing Failed',
          description: response.message,
          variant: 'destructive',
        });
        return false;
      }
    } catch (error) {
      console.error('Error in shareWithFallback:', error);
      
      // API sharing failed with exception, try fallback if configured
      if (config.useFallbackForm) {
        this.openCaspioForm(data, config.tableId);
        return true;
      } else {
        toast({
          title: 'Sharing Failed',
          description: 'An unexpected error occurred',
          variant: 'destructive',
        });
        return false;
      }
    }
  }
  
  /**
   * Check if Caspio integration is configured
   * 
   * @returns True if Caspio integration is configured
   */
  static async isCaspioConfigured(): Promise<boolean> {
    try {
      const response = await axios.get('/api/caspio/config');
      return response.data.configured === true;
    } catch (error) {
      console.error('Error checking Caspio configuration:', error);
      return false;
    }
  }
}

export default CaspioService;