# Caspio Integration Setup Guide

This guide provides detailed instructions for setting up the Caspio integration with your Smarty Pants Trivia Co. application.

## Prerequisites

Before beginning, ensure you have:

1. A Caspio account with access to their REST API
2. Your Caspio account credentials
3. A Caspio table set up to receive event data

## Step 1: Environment Variables Setup

Add the following environment variables to your application:

```
CASPIO_ACCOUNT_ID=your_account_id_here
CASPIO_USERNAME=your_username_here
CASPIO_PASSWORD=your_password_here
CASPIO_APP_KEY=your_app_key_here (optional)
CASPIO_TABLE_ID=your_table_id_here (defaults to 'Events' if not specified)
```

You can add these to your `.env` file or set them in your hosting environment.

## Step 2: Server-Side Integration

1. Copy `caspio.ts` to your server's routes directory
2. Register the Caspio routes in your main server file:

```typescript
// In your server/index.ts or equivalent
import { registerCaspioRoutes } from './routes/caspio';

// After setting up your Express app
registerCaspioRoutes(app);
```

## Step 3: Client-Side Integration

1. Copy the client-side files to their respective directories:
   - `caspioConfig.ts` and `caspioService.ts` to your `client/src/lib/` directory
   - `CaspioStatusIndicator.tsx` to your `client/src/components/` directory
   - `caspio-settings.tsx` to your `client/src/pages/portal/` directory
   - `ShareableEventCard.tsx` to your `client/src/components/home/` directory (or adapt it for your specific component structure)

2. Update your app routing to include the Caspio settings page:

```typescript
// In your App.tsx or equivalent
import CaspioSettingsPage from "./pages/portal/caspio-settings";

// In your routes section
<Route path="/portal/caspio-settings" component={CaspioSettingsPage} />
```

3. Add the Caspio status indicator to your Navbar component:

```typescript
// In your Navbar.tsx
import CaspioStatusIndicator from "./CaspioStatusIndicator";

// Add this to your navbar items area
<div className="hidden lg:flex items-center">
  <CaspioStatusIndicator />
</div>
```

4. Update your portal navigation to include a link to Caspio settings (for admin users):

```typescript
// In your portal navigation component
{isAdmin && (
  <a 
    href="/portal/caspio-settings" 
    className="inline-flex items-center px-3 py-2 text-sm font-medium"
  >
    Caspio Settings
  </a>
)}
```

## Step 4: Using the Share to Caspio Functionality

You can use the ShareableEventCard component as is, or implement the share functionality in your own components:

```typescript
import CaspioService from '@/lib/caspioService';

// In your component
const handleShareToCaspio = async () => {
  try {
    setIsSharing(true); // Set a loading state
    
    // Use the Caspio service to share data
    const success = await CaspioService.shareWithFallback(eventData);
    
    if (success) {
      // Handle success
      toast({
        title: 'Shared Successfully',
        description: 'Event has been shared to Caspio'
      });
    }
  } catch (error) {
    // Handle error
    console.error('Error sharing to Caspio:', error);
  } finally {
    setIsSharing(false); // Clear loading state
  }
};
```

## Step 5: Testing the Integration

1. Navigate to the Caspio Settings page in your admin portal
2. Verify that the connection status shows "Connected" if all credentials are provided
3. Use the "Test Connection" button to verify API connectivity
4. Try sharing an event using the "Share to Caspio" button

## Troubleshooting

If you encounter issues:

1. Check the browser console for error messages
2. Verify that all environment variables are correctly set
3. Ensure your Caspio account has API access enabled
4. Check that the table structure in Caspio matches the expected fields
5. If the API integration fails, the fallback form submission should still work

## Customizing the Integration

To customize the integration for your specific Caspio setup:

1. Update the field mappings in `caspioConfig.ts` to match your Caspio table structure
2. Modify the form URL pattern in `getCaspioFormUrl()` if you have a custom form URL
3. Adjust the styling of the components to match your application's design

## Security Notes

- Keep your Caspio credentials secure and never expose them in client-side code
- Consider implementing rate limiting to prevent abuse of the sharing functionality
- Regularly rotate your Caspio credentials as a security best practice