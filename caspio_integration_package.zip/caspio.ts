import { Request, Response } from 'express';
import axios from 'axios';

// Environment variables for Caspio
const CASPIO_ACCOUNT_ID = process.env.CASPIO_ACCOUNT_ID;
// APP_KEY is optional - some Caspio setups use client_credentials flow instead
const CASPIO_APP_KEY = process.env.CASPIO_APP_KEY;
const CASPIO_USERNAME = process.env.CASPIO_USERNAME;
const CASPIO_PASSWORD = process.env.CASPIO_PASSWORD;
const CASPIO_TABLE_ID = process.env.CASPIO_TABLE_ID || 'Events';

// Token cache to avoid frequent authentication requests
let caspioToken: string | null = null;
let tokenExpiry: number = 0;

/**
 * Authenticate with Caspio API and get access token
 */
async function getCaspioToken(): Promise<string | null> {
  // Check if we have a valid cached token
  const now = Date.now();
  if (caspioToken && tokenExpiry > now) {
    return caspioToken;
  }

  // Check if we have necessary credentials
  if (!CASPIO_ACCOUNT_ID || !CASPIO_USERNAME || !CASPIO_PASSWORD) {
    console.error('Missing Caspio API credentials');
    return null;
  }

  try {
    // Prepare request body based on available credentials
    const requestBody: any = {
      grant_type: 'password',
      username: CASPIO_USERNAME,
      password: CASPIO_PASSWORD
    };
    
    // Add client_id if APP_KEY is available
    if (CASPIO_APP_KEY) {
      requestBody.client_id = CASPIO_APP_KEY;
    }

    const response = await axios.post(
      `https://${CASPIO_ACCOUNT_ID}.caspio.com/oauth/token`,
      requestBody
    );

    // Cache the token and set expiry (typically 1 hour)
    caspioToken = response.data.access_token;
    // Set expiry 5 minutes before actual expiry to be safe
    tokenExpiry = now + (response.data.expires_in - 300) * 1000;
    
    return caspioToken;
  } catch (error) {
    console.error('Caspio authentication failed:', error);
    return null;
  }
}

/**
 * Handle sending event data to Caspio
 */
export async function handleCaspioShare(req: Request, res: Response) {
  try {
    const { eventData } = req.body;
    
    if (!eventData) {
      return res.status(400).json({ error: 'Event data is required' });
    }
    
    const token = await getCaspioToken();
    
    if (!token) {
      return res.status(500).json({ error: 'Failed to authenticate with Caspio' });
    }
    
    // Format the data according to Caspio's requirements
    const formattedData = {
      EventID: eventData.id,
      EventTitle: eventData.title,
      EventDescription: eventData.description,
      EventDate: eventData.date,
      Venue: eventData.venue,
      ImageURL: eventData.imageUrl || '',
      ShareTimestamp: new Date().toISOString()
    };
    
    // Send data to Caspio
    const response = await axios.post(
      `https://${CASPIO_ACCOUNT_ID}.caspio.com/rest/v2/tables/${CASPIO_TABLE_ID}/records`,
      formattedData,
      {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      }
    );
    
    return res.status(201).json({
      success: true,
      message: 'Event shared to Caspio successfully',
      data: response.data
    });
  } catch (error: any) {
    console.error('Error sharing to Caspio:', error);
    return res.status(500).json({
      error: 'Failed to share event to Caspio',
      message: error.message
    });
  }
}

/**
 * Get Caspio configuration settings
 */
export function getCaspioConfigHandler(_req: Request, res: Response) {
  // APP_KEY is optional, so only check for account ID, username and password
  const isConfigured = Boolean(CASPIO_ACCOUNT_ID && CASPIO_USERNAME && CASPIO_PASSWORD);
  
  // If not configured, suggest potential action
  if (!isConfigured) {
    console.log(
      'Caspio integration is not fully configured. ' + 
      'Set CASPIO_ACCOUNT_ID, CASPIO_USERNAME, and CASPIO_PASSWORD environment variables. CASPIO_APP_KEY is optional.'
    );
    
    return res.status(200).json({
      configured: false,
      message: 'Caspio is not fully configured',
      missingCredentials: [
        ...(CASPIO_ACCOUNT_ID ? [] : ['CASPIO_ACCOUNT_ID']),
        ...(CASPIO_USERNAME ? [] : ['CASPIO_USERNAME']),
        ...(CASPIO_PASSWORD ? [] : ['CASPIO_PASSWORD'])
      ]
    });
  }
  
  return res.status(200).json({
    configured: true,
    accountID: CASPIO_ACCOUNT_ID,
    appKey: CASPIO_APP_KEY,
    tableID: CASPIO_TABLE_ID
  });
}

/**
 * Test connection to Caspio API
 */
export async function testCaspioConnection(req: Request, res: Response) {
  try {
    // Check if essential credentials are available (APP_KEY is optional)
    if (!CASPIO_ACCOUNT_ID || !CASPIO_USERNAME || !CASPIO_PASSWORD) {
      return res.status(200).json({
        success: false,
        message: 'Missing Caspio credentials'
      });
    }
    
    // Try to get a token
    const token = await getCaspioToken();
    
    if (!token) {
      return res.status(200).json({
        success: false,
        message: 'Failed to authenticate with Caspio'
      });
    }
    
    // If we got a token, try a simple API call to verify it works
    try {
      // Make a simple request to verify the token works
      await axios.get(
        `https://${CASPIO_ACCOUNT_ID}.caspio.com/rest/v2/tables`,
        {
          headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json'
          }
        }
      );
      
      return res.status(200).json({
        success: true,
        message: 'Successfully connected to Caspio API'
      });
    } catch (error) {
      console.error('Error verifying Caspio connection:', error);
      return res.status(200).json({
        success: false,
        message: 'Authentication successful but API access failed'
      });
    }
  } catch (error: any) {
    console.error('Error testing Caspio connection:', error);
    return res.status(200).json({
      success: false,
      message: error.message || 'Unknown error occurred'
    });
  }
}

/**
 * Register Caspio routes with Express app
 */
export function registerCaspioRoutes(app: any) {
  app.post('/api/caspio/share', handleCaspioShare);
  app.get('/api/caspio/config', getCaspioConfigHandler);
  app.post('/api/caspio/test-connection', testCaspioConnection);
}