import { useState } from 'react';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import CaspioService from '@/lib/caspioService';
import { defaultCaspioConfig } from '@/lib/caspioConfig';

interface ShareableEventCardProps {
  event: {
    id: string;
    title: string;
    description: string;
    date: string;
    venueName: string;
    imageUrl?: string;
  };
}

/**
 * Event card with functionality to share to Caspio
 */
export default function ShareableEventCard({ event }: ShareableEventCardProps) {
  const [isSharing, setIsSharing] = useState(false);
  const { toast } = useToast();

  /**
   * Handle sharing the event to Caspio
   */
  const handleShareToCaspio = async () => {
    try {
      setIsSharing(true);
      
      // Use the Caspio service to share data
      const success = await CaspioService.shareWithFallback(event);
      
      if (success) {
        toast({
          title: 'Shared Successfully',
          description: 'Event has been shared to Caspio'
        });
      }
    } catch (error) {
      console.error('Error sharing to Caspio:', error);
      toast({
        title: 'Sharing Failed',
        description: 'An error occurred while sharing to Caspio',
        variant: 'destructive'
      });
    } finally {
      setIsSharing(false);
    }
  };

  // Format the date nicely
  const formattedDate = new Date(event.date).toLocaleDateString('en-US', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  });

  return (
    <Card className="overflow-hidden shadow-lg transition-all duration-300 hover:shadow-xl">
      {event.imageUrl && (
        <div className="relative h-40 overflow-hidden">
          <img 
            src={event.imageUrl} 
            alt={event.title} 
            className="absolute inset-0 h-full w-full object-cover transition-transform duration-500 hover:scale-105" 
          />
        </div>
      )}
      
      <CardHeader className="pb-2">
        <CardTitle className="text-xl text-[#0A2463]">
          {event.title}
        </CardTitle>
        <div className="text-sm text-[#0A2463]/70">
          {formattedDate}
        </div>
      </CardHeader>
      
      <CardContent className="pb-2">
        <p className="text-gray-600 line-clamp-3">{event.description}</p>
        <p className="mt-2 text-sm font-medium text-[#2B9DF4]">
          {event.venueName}
        </p>
      </CardContent>
      
      <CardFooter className="flex justify-between pt-2">
        <Button 
          variant="outline" 
          size="sm"
          onClick={() => {
            // Handle view details action
            toast({
              title: 'View Event',
              description: `Viewing details for ${event.title}`
            });
          }}
        >
          View Details
        </Button>
        
        <Button
          size="sm"
          className="bg-[#FF8B7C] hover:bg-[#FF7B6C] text-white"
          onClick={handleShareToCaspio}
          disabled={isSharing}
        >
          {isSharing ? (
            <>
              <span className="mr-2 inline-block h-4 w-4 animate-spin rounded-full border-2 border-white border-t-transparent"></span>
              Sharing...
            </>
          ) : (
            <>Share to Caspio</>
          )}
        </Button>
      </CardFooter>
    </Card>
  );
}