/**
 * Configuration settings for Caspio integration
 */

/**
 * Get the Caspio form URL based on the table ID
 * This is used as a fallback if direct API interaction fails
 * 
 * @param tableId The Caspio table ID to submit data to
 * @returns The URL for the Caspio form
 */
export const getCaspioFormUrl = (tableId: string): string => {
  // This is a template for Caspio form URLs
  // For actual implementation, this should be configured based on the specific Caspio deployment
  return `https://c0abc123.caspio.com/dp/${tableId}`;
};

/**
 * Prepare data for submission to Caspio
 * This function formats the data based on Caspio's expected structure
 * 
 * @param data Raw data to be formatted for Caspio
 * @returns Formatted data for Caspio submission
 */
export const prepareCaspioData = (data: any): any => {
  // Map data fields to Caspio field names
  // Adjust field mappings based on your Caspio database structure
  return {
    EventID: data.id,
    EventTitle: data.title,
    EventDescription: data.description,
    EventDate: data.date,
    VenueName: data.venueName,
    ImageURL: data.imageUrl,
    SharedTimestamp: new Date().toISOString(),
    // Add any other fields relevant to your Caspio database
  };
};

/**
 * Default configuration for Caspio integration
 */
export const defaultCaspioConfig = {
  // Default table ID for event data
  tableId: 'eventdata',
  
  // Default fallback option if API fails
  useFallbackForm: true,
  
  // Maximum retry attempts for API submission
  maxRetries: 2,
  
  // Delay between retries in milliseconds
  retryDelay: 1000,
};